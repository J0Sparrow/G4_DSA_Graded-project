/**
 * 
 */
/**
 * @author devilvirus
 *
 */
module OOPS_LAB1 {
}